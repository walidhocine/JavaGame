/**
 * 
 */
package walidgame;



import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import BoulderDash.Modele.Cases.Diamant;

/**
 * @author WALID
 *
 */
public class TestDiamant {

	/**
	 * @throws java.lang.Exception
	 * 
	 * 
	 * 
	 */
	

	
	
	@BeforeClass
	public static void setUpBeforeClass() {
	}

	Diamant D = new Diamant(0,0);	
	
	/**
	 * Test method for {@link BoulderDash.Modele.Cases.Diamant#ID()}.
	 */
	@Test
	public void testID() {
	
		Assert.assertEquals("c",0 , 0);		
		
	}

}
