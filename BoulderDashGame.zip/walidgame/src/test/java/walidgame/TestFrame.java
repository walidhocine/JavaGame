/**
 * 
 */
package walidgame;



import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import BoulderDash.Modele.Animation.Frame;

/**
 * @author WALID
 *
 */


public class TestFrame {

	static Frame f;
	
	
	@BeforeClass
	public  static void setUpBeforeClass()  {
		
		f = new Frame(null, 5);
	}



	

	/**
	 * Test method for {@link BoulderDash.Modele.Animation.Frame#setduree(int)}.
	 */
	@Test
	public void testSetduree() {
		
		Frame f = new Frame(null, 8);
		
		Assert.assertSame(8, f.getduree());
	}
	
	/**
	 * Test method for {@link BoulderDash.Modele.Animation.Frame#getduree()}.
	 */

	@Test
	public void testGetduree() {
		
		//Assert.assertEquals(0, 0);
		
		
		System.out.println(f.getduree());
	
	   
	    
	    assertEquals(5, f.getduree());
		
	}

}
