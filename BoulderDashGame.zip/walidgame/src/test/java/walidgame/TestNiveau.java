/**
 * 
 */
package walidgame;



import org.junit.Before;

import org.junit.Test;

import BoulderDash.Modele.Niveau;

/**
 * @author WALID
 *
 */
public class TestNiveau {

	/**
	 * @throws java.lang.Exception
	 */
	
	static Niveau NiveauJeux;
	
	@Before
	public void setUpBeforeClass(){
	NiveauJeux  =new Niveau();
	
	}
	
	
	

	/**
	 * Test method for {@link BoulderDash.Modele.Niveau#insereVide(int, int)}.
	 */
	

	/**
	 * Test method for {@link BoulderDash.Modele.Niveau#remplirUpTable(int, int)}.
	 */
	
	
	// test the methode RemplireUptable
	@Test
	public void testRemplirUpTable(){
		Niveau NiveauJ = new Niveau(7,5);
		NiveauJ.addUptable(6,4);
		NiveauJ.addUptable(6,3);
		NiveauJ.addUptable(5,3);
		NiveauJ.addUptable(5,4);
	}
	
	
	
	
	// test if the methode recieve a int value 

	public void test2RemplirUpTable(){
		Niveau NiveauJ = new Niveau(7,5);
		NiveauJ.addUptable(6,4);
		NiveauJ.addUptable(6,3);
		NiveauJ.addUptable(5,3);
		NiveauJ.addUptable(5,4);
}

}
